//Xuất các giá trị nhỏ hơn 50 và là số chẵn ra màn hình
public class Test_2 {

	public static void main(String[] args) {
		for (int i=0; i<50; i++) {
			if (i % 2 == 0) {
				System.out.println(i);
			}
		}

	}

}
