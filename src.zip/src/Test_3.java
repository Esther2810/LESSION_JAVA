//Tính tổng các số lẻ nhỏ hơn 500 và in ra màn hình
public class Test_3 {

	public static void main(String[] args) {
		int sum = 0;
		for (int i = 1; i < 50; i++) {
			if (i % 2 != 0) {
				sum = sum + i;
			}
		}
			System.out.println("Tổng số lẻ nhỏ hơn 50 là: " + sum + "" );
	}

}