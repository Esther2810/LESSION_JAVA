//*
//*  *
//*  *  *
//*  *  *  *
//*  *  *  *  *
// Sử dụng kí tự * để in ra màn hình , hình như trên
public class Test_5 {

	public static void main(String[] args) {
		int n = 0;
		for (int x = 0; x < 5; x++) {
			for (int y = 0; y <= n; y++) {
				System.out.print("*");
			}
			n = n + 1;
			System.out.println();
		}

	}

}
