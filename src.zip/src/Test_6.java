/*	1  2  3  4  5
	1  2  3  4
	1  2  3
	1  2
	1
	in ra màn hình , hình như trên */
public class Test_6 {

	public static void main(String[] args) {
		int n = 6;
		for (int x = 1; x < 6; x++) {
			for(int y = 1; y < n; y++) {
				System.out.print(y + " ");
			}
		System.out.println();
		n = n-1;
		}

	}

}
